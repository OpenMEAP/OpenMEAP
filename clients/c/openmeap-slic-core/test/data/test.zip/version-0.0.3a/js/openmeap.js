if( typeof OpenMEAP=="undefined" ) {
	OpenMEAP = {
		config:{
			deviceType:"Browser"
		}
	};
}
OpenMEAP.persist = {};
OpenMEAP.persist.cookie = {};

if( typeof OpenMEAP.setTitle != "function" ) {
	OpenMEAP.setTitle = function(text) { document.title=text; }
}

if( typeof OpenMEAP.doToast != "function" )
	OpenMEAP.doToast = function(text,duration) { alert(text); }

if( typeof OpenMEAP.getDeviceType == "undefined" ) {
	OpenMEAP.getDeviceType = function() { return OpenMEAP.config.deviceType; }
}

if( typeof OpenMEAP.getPreferences == "undefined" ) {
	OpenMEAP.getPreferences = function(name) {
		var c_name = "OpenMEAP_keyValuePairs_"+name;
		var values = unescape(OpenMEAP.persist.cookie.get(c_name));
		eval("var values = "+values);
		var toRet = {
			cookieName:c_name,
			cookieValues:(typeof values == "object" ? values : {}),
			get:function(key){
				return this.cookieValues[key];
			},
			put:function(key,value) {
				this.cookieValues[key]=value;
				var values = escape(OpenMEAP.utils.toJSON(this.cookieValues));
				this.setCookie();
			},
			remove:function(key) {
				var newValues = {}
				for( i in this.cookieValues )
					if( i != key )
						newValues[i]=this.cookieValues[key];
				this.cookieValues = newValues;
				this.setCookie();
			},
			clear:function() {
				this.cookieValues = {};
				this.setCookie();
			},
			setCookie:function(){
				OpenMEAP.persist.cookie.set(this.cookieName,escape(OpenMEAP.utils.toJSON(this.cookieValues)));
			}
		};
		return toRet;
	}
}

OpenMEAP.utils = {
	toJSON:function(obj) {
		if( typeof obj == "object" ) {
			if( typeof obj.length != "number" ) {
				var str = "{"
				for( key in obj ) {
					var val = key+":"+OpenMEAP.utils.toJSON(obj[key]);
					str += ( str.length>1 ? ","+val : val ); 
				}
				str += "}";
				return str;
			} else {
				var str = "[";
				for( var i=0; i<obj.length; i++ ) {
					var val = OpenMEAP.utils.toJSON(obj[i]);
					str += ( i>0 ? ","+val : val );
				}
				str += "]";
				return str;
			}
		} else if( typeof obj == "string" )
			return "\""+obj+"\"";
		else if( typeof obj == "number" )
			return ""+obj;
	},
	paramsToObj:function(str) {
		var vars = str.split("&");
		var retObj = {};
		for( var i=0; i<vars.length; i++ ) {
			var parts = vars[i].split("=");
			if( parts.length > 1 )
				retObj[parts[0]]=parts[1];
			else retObj[parts[0]]=true;
		}
		return retObj;
	}
};

{
	try {
		var useSessionStorage = false;
		if( sessionStorage != null )
			var useSessionStorage = true;
	} catch(e) {
		;
	}
	if( ! useSessionStorage ) {
		OpenMEAP.persist.keyPairs = {
			setup:function()             { this.prefs = OpenMEAP.getPreferences("keyPairs"); },
			getItem:function(key)        { if(typeof this.prefs=="undefined") this.setup(); if(this.prefs.get(key)) return unescape(this.prefs.get(key)); },
			setItem:function(key, value) { if(typeof this.prefs=="undefined") this.setup(); this.prefs.put(key,escape(value)); },
			removeItem:function(key)     { if(typeof this.prefs=="undefined") this.setup(); this.prefs.remove(key); },
			clear:function()             { if(typeof this.prefs=="undefined") this.setup(); this.prefs.clear(); }
		};
	} else {
		OpenMEAP.persist.keyPairs = {
			getItem:function(key)        { return sessionStorage.getItem(key); },
			setItem:function(key, value) { sessionStorage.setItem(key,value); },
			removeItem:function(key)     { sessionStorage.removeItem(key); },
			clear:function()             { sessionStorage.clear(); }
		};
	}
}
	
OpenMEAP.persist.cookie.set = function(name,value,expireDays) {
	var expireDate = new Date();
	expireDate.setDate(expireDate.getDate() + expireDays);
	var c_value = escape(value) + ((expireDays==null) ? "" : "; expires="+expireDate.toUTCString());
	document.cookie = name + "=" + c_value;
}
OpenMEAP.persist.cookie.get = function(name) {
	var i,key,value,ARRcookies = document.cookie.split(";");
	for (i=0; i<ARRcookies.length; i++)
	{
	  key   = ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
	  value = ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
	  key   = key.replace(/^\s+|\s+$/g,"");
	  if (key == name)
	  {
		  return unescape(value);
	  }
	}
}
